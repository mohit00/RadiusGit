export const environment = {
  production: true,
  apiUrl: 'http://my-api-url'

};
