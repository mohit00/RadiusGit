import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-quick-help',
  templateUrl: './quick-help.component.html',
  styleUrls: ['./quick-help.component.scss']
})
export class QuickHelpComponent implements OnInit {
  constructor() { }
  ngOnInit() {
  }
}