import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arrtibute-select',
  templateUrl: './arrtibute-select.component.html',
  styleUrls: ['./arrtibute-select.component.scss']
})
export class ArrtibuteSelectComponent implements OnInit {

  constructor() { 

    
  }

  ngOnInit() {
  }

}
